<!doctype html>
<html lang="en">
<?php $this->load->view('app/includes/headerfiles'); ?>
	<body>
		<div id="loader">
			<img src="<?=base_url();?>assets/app/img/loading-icon.png" alt="icon" class="loading-icon">
		</div>
		<?php $this->load->view('app/includes/sidebar'); ?>
			